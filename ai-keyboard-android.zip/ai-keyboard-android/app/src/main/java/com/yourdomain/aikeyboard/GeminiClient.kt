package com.yourdomain.aikeyboard

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Lightweight Gemini 2.5 Flash client — no external SDK needed.
 * Uses only Android's built-in java.net.HttpURLConnection.
 */
class GeminiClient(private val apiKey: String) {

    companion object {
        private const val BASE_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
        private const val TIMEOUT_MS = 30_000
    }

    // ── Public API ──────────────────────────────────────────────────────────

    suspend fun improveText(text: String): String {
        val prompt = """
            Rewrite the following message in a clear, professional, and polished tone.
            - Keep the original meaning intact
            - Fix grammar and spelling
            - Make it sound confident and articulate
            - Do NOT add explanations or preambles — return ONLY the improved text

            Text:
            $text
        """.trimIndent()
        return generate(prompt)
    }

    suspend fun formatText(text: String): String {
        val prompt = """
            Format and structure the following message professionally.
            - Use proper paragraphs and punctuation
            - Add clear organization (greeting, body, closing if appropriate)
            - Ensure formal and structured tone
            - Do NOT add explanations or preambles — return ONLY the formatted text

            Text:
            $text
        """.trimIndent()
        return generate(prompt)
    }

    // ── Core request ────────────────────────────────────────────────────────

    private suspend fun generate(prompt: String): String = withContext(Dispatchers.IO) {
        val url = URL("$BASE_URL?key=$apiKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod        = "POST"
            connectTimeout       = TIMEOUT_MS
            readTimeout          = TIMEOUT_MS
            doOutput             = true
            setRequestProperty("Content-Type", "application/json")
        }

        val body = buildRequestBody(prompt)

        try {
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(body)
                writer.flush()
            }

            val responseCode = connection.responseCode
            val responseText = if (responseCode == 200) {
                connection.inputStream.bufferedReader().readText()
            } else {
                val error = connection.errorStream?.bufferedReader()?.readText() ?: "Unknown error"
                throw Exception("HTTP $responseCode: $error")
            }

            parseResponse(responseText)

        } finally {
            connection.disconnect()
        }
    }

    private fun buildRequestBody(prompt: String): String {
        return JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 1024)
                put("topP", 0.9)
            })
        }.toString()
    }

    private fun parseResponse(json: String): String {
        return try {
            val root       = JSONObject(json)
            val candidates = root.getJSONArray("candidates")
            val content    = candidates.getJSONObject(0).getJSONObject("content")
            val parts      = content.getJSONArray("parts")
            parts.getJSONObject(0).getString("text").trim()
        } catch (e: Exception) {
            throw Exception("Failed to parse Gemini response: ${e.message}")
        }
    }
}
