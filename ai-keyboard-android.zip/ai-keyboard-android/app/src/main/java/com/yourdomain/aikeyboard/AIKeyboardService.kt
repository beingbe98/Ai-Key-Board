package com.yourdomain.aikeyboard

import android.inputmethodservice.InputMethodService
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import kotlinx.coroutines.*

class AIKeyboardService : InputMethodService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var keyboardView: View
    private lateinit var geminiClient: GeminiClient

    override fun onCreate() {
        super.onCreate()
        geminiClient = GeminiClient(BuildConfig.GEMINI_API_KEY)
    }

    override fun onCreateInputView(): View {
        keyboardView = LayoutInflater.from(this)
            .inflate(R.layout.keyboard_view, null)

        setupAIButtons()
        setupKeyboard()
        return keyboardView
    }

    // ── AI Toolbar Buttons ──────────────────────────────────────────────────

    private fun setupAIButtons() {
        val btnImprove = keyboardView.findViewById<Button>(R.id.btn_improve)
        val btnFormat  = keyboardView.findViewById<Button>(R.id.btn_format)

        btnImprove.setOnClickListener { handleAIAction(AIAction.IMPROVE) }
        btnFormat.setOnClickListener  { handleAIAction(AIAction.FORMAT)  }
    }

    private fun handleAIAction(action: AIAction) {
        val ic = currentInputConnection ?: return

        // Grab current text from the input field (up to 2000 chars)
        val selectedText = ic.getSelectedText(0)?.toString()
        val currentText  = selectedText
            ?: ic.getTextBeforeCursor(2000, 0)?.toString()?.trim()
            ?: return

        if (currentText.isBlank()) {
            Toast.makeText(this, "Type something first!", Toast.LENGTH_SHORT).show()
            return
        }

        setButtonsEnabled(false)
        showLoadingState(action)

        serviceScope.launch {
            try {
                val result = when (action) {
                    AIAction.IMPROVE -> geminiClient.improveText(currentText)
                    AIAction.FORMAT  -> geminiClient.formatText(currentText)
                }
                replaceText(currentText, result, selectedText != null)
                Toast.makeText(
                    this@AIKeyboardService,
                    if (action == AIAction.IMPROVE) "✨ Text improved!" else "📐 Text formatted!",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(this@AIKeyboardService,
                    "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                setButtonsEnabled(true)
                resetButtonState()
            }
        }
    }

    private fun replaceText(original: String, replacement: String, isSelection: Boolean) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        if (isSelection) {
            ic.commitText(replacement, 1)
        } else {
            // Delete original text and commit new
            ic.deleteSurroundingText(original.length, 0)
            ic.commitText(replacement, 1)
        }
        ic.endBatchEdit()
    }

    // ── Keyboard Setup ──────────────────────────────────────────────────────

    private fun setupKeyboard() {
        val keyboardLayout = keyboardView.findViewById<LinearLayout>(R.id.keyboard_layout)
        val rows = listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("123","space","return")
        )
        // Keys are inflated from XML layout (see keyboard_view.xml)
        // Click listeners set here for each key button by ID naming convention
        setupKeyListeners()
    }

    private fun setupKeyListeners() {
        val ic get() = currentInputConnection

        // Letter keys — found by tag in keyboard_view.xml
        keyboardView.findViewsWithTag("letter_key", View::class.java).forEach { view ->
            val btn = view as? Button ?: return@forEach
            btn.setOnClickListener {
                ic?.commitText(btn.text.toString().lowercase(), 1)
            }
        }

        keyboardView.findViewById<Button>(R.id.key_backspace)?.setOnClickListener {
            ic?.deleteSurroundingText(1, 0)
        }

        keyboardView.findViewById<Button>(R.id.key_space)?.setOnClickListener {
            ic?.commitText(" ", 1)
        }

        keyboardView.findViewById<Button>(R.id.key_return)?.setOnClickListener {
            ic?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
        }
    }

    // ── UI State ────────────────────────────────────────────────────────────

    private fun setButtonsEnabled(enabled: Boolean) {
        keyboardView.findViewById<Button>(R.id.btn_improve)?.isEnabled = enabled
        keyboardView.findViewById<Button>(R.id.btn_format)?.isEnabled  = enabled
    }

    private fun showLoadingState(action: AIAction) {
        when (action) {
            AIAction.IMPROVE -> keyboardView.findViewById<Button>(R.id.btn_improve)
                ?.text = "Improving…"
            AIAction.FORMAT  -> keyboardView.findViewById<Button>(R.id.btn_format)
                ?.text = "Formatting…"
        }
    }

    private fun resetButtonState() {
        keyboardView.findViewById<Button>(R.id.btn_improve)?.text = "✨ Improve"
        keyboardView.findViewById<Button>(R.id.btn_format)?.text  = "📐 Format"
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    enum class AIAction { IMPROVE, FORMAT }
}

// Helper extension to find views by tag (simplified)
fun <T : View> View.findViewsWithTag(tag: String, clazz: Class<T>): List<T> {
    val result = mutableListOf<T>()
    if (this is android.view.ViewGroup) {
        for (i in 0 until childCount) {
            result.addAll(getChildAt(i).findViewsWithTag(tag, clazz))
        }
    }
    if (this.tag == tag && clazz.isInstance(this)) {
        @Suppress("UNCHECKED_CAST")
        result.add(this as T)
    }
    return result
}
