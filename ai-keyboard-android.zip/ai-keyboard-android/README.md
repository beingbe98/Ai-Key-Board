# ✨ AI Keyboard — Android

> A personal Android custom keyboard powered by **Gemini 2.5 Flash** that rewrites and formats your text professionally — right from the keyboard toolbar.

![Platform](https://img.shields.io/badge/Platform-Android-green?style=flat-square&logo=android)
![Language](https://img.shields.io/badge/Language-Kotlin-purple?style=flat-square&logo=kotlin)
![API](https://img.shields.io/badge/AI-Gemini%202.5%20Flash-blue?style=flat-square&logo=google)
![License](https://img.shields.io/badge/License-MIT-orange?style=flat-square)

---

## 📱 What It Does

This is a fully functional Android IME (Input Method Editor) — a real keyboard you can use in **any app** on your phone. Above the QWERTY keys, there's an AI toolbar with two buttons:

| Button | What It Does |
|--------|-------------|
| ✨ **Improve** | Rewrites your typed text in a professional, polished tone |
| 📐 **Format** | Structures your text with proper paragraphs and punctuation |

Type rough → tap a button → Gemini rewrites it → text is replaced instantly.

---

## 🎬 Demo

> Open `prototype/ai_keyboard_prototype.html` in any browser to try it live with your Gemini API key.

---

## 🗂️ Project Structure

```
ai-keyboard-android/
├── app/src/main/
│   ├── java/com/yourdomain/aikeyboard/
│   │   ├── AIKeyboardService.kt     # Core IME keyboard service
│   │   └── GeminiClient.kt          # Gemini 2.5 Flash REST client
│   ├── res/
│   │   ├── layout/keyboard_view.xml # Keyboard UI with AI toolbar
│   │   ├── drawable/                # Button & key backgrounds
│   │   ├── values/styles.xml        # Key styles
│   │   └── xml/method.xml           # IME subtype declaration
│   └── AndroidManifest.xml
├── prototype/
│   └── ai_keyboard_prototype.html   # Browser-testable prototype
├── build.gradle
└── README.md
```

---

## 🚀 Setup & Installation

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/ai-keyboard-android.git
cd ai-keyboard-android
```

### 2. Get a free Gemini API key
Go to [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey) and create a key.

### 3. Add your API key
In `app/build.gradle`, find and update:
```groovy
buildConfigField "String", "GEMINI_API_KEY", '"YOUR_API_KEY_HERE"'
```

### 4. Build in Android Studio
- Open Android Studio → Open this project folder
- Wait for Gradle sync to finish
- Click **Run ▶** with your phone connected via USB

### 5. Enable on your Android phone
```
Settings → General Management → Keyboard
→ On-screen keyboard → Manage keyboards
→ Toggle ON "AI Keyboard"
```

### 6. Switch to it
In any app → tap keyboard icon in navigation bar → select **AI Keyboard**

---

## 🛠️ Tech Stack

- **Language:** Kotlin
- **Architecture:** Android IME (InputMethodService)
- **AI:** Gemini 2.5 Flash (REST API, no external SDK)
- **Async:** Kotlin Coroutines
- **Min SDK:** Android 8.0 (API 26)

---

## 💡 How It Works

```
User types text in any app
        ↓
Taps [✨ Improve] or [📐 Format]
        ↓
AIKeyboardService reads text via InputConnection
        ↓
GeminiClient sends prompt to Gemini 2.5 Flash
        ↓
AI response replaces original text instantly
        ↓
Toast confirmation shown
```

---

## 📄 License

MIT License — free to use, modify, and share for personal use.

---

## 👤 Author

**Prakash** — [prakashconnects.wixsite.com/prakashconnects](https://prakashconnects.wixsite.com/prakashconnects)

> Built as a personal productivity tool to write professionally, faster.
